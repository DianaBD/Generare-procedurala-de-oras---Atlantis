#pragma once
#include <Component/SimpleScene.h>
#include "LabCamera.h"
/*
#include "Area.h"
#include "Ground.h"
#include "Vehicles.h"
#include "Sidewalks.h"
#include "Building.h"
*/

#include <Component/Transform/Transform.h>
#include <Core/GPU/Mesh.h>

class Tema3 : public SimpleScene
{
	public:
		Tema3();
		~Tema3();

		void Init() override;

		/* //adaugate
		void draw();
		inline glm::vec3 getBackgroundColor() const { return lightColor * fogColor; }
		inline const glm::mat4& getView() const { return view; }
		inline const glm::mat4& getProj() const { return proj; }
		inline const glm::vec3& getViewPos() const { return viewPos; }
		inline int getWorldHeight() const { return worldHeight; }
		inline int getWorldWidth() const { return worldWidth; }
		inline const glm::vec3& getLightPos() const { return lightPos; }
		inline const glm::vec3& getLightColor() const { return lightColor; }
		inline const glm::vec3& getLightDirection() const { return lightDirection; }
		*/


		/**
		*	@return the primary shader of the world
		*/
		//inline const glutil::Shader& getShader() const { return *bldShader; }
		/**
		*	@return the time elapsed since last render
		*/
		inline const GLfloat getDeltaTime() const { return deltaTime; }
		/**
		*	@return the center of the world
		*/
		inline glm::vec3 center() const;
		/**
		*	Collision detection with a 3D point.
		*	@param a 3D point to query against
		*	@return true if any entitiy in the world contains the specified point
		*/
		bool intersectsPoint(const glm::vec3& point) const;
		/**
		*	Return the grid coordinate of the area for the specified sizes of the grid
		*	@param a the area
		*	@param width the width of the grid
		*	@param height the height of the grid
		*	@return a pair of coordinates in Z and X directions specifying the row and the column of the coordinate
		*	The origin of the grid is considered the topleft corner of the world
		*/
		void makeStreets();
		//std::pair<std::size_t, std::size_t> areaCoordinate(const Area& a, std::size_t width, std::size_t height) const;
		bool enableFog = true;

		float worldWidth;
		float worldHeight;
		const float PI = 3.1415926f;

		float sidewalk = 0.1;
		float largeSidewalk = 0.2;
		float smallRoad = 0.2;
		float mediumRoad = 0.3;
		float largeRoad = 0.5;

	private:
		void FrameStart() override;
		void Update(float deltaTimeSeconds) override;
		void FrameEnd() override;

		void RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 &modelMatrix, const glm::vec3 &color, Texture2D* texture1, int isSky, int isBuilding, std::string name);
		void RenderSimpleMeshTex(Mesh *mesh, Shader *shader, const glm::mat4 & modelMatrix, Texture2D* texture1);

		void OnInputUpdate(float deltaTime, int mods) override;
		void OnKeyPress(int key, int mods) override;
		void OnKeyRelease(int key, int mods) override;
		void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
		void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
		void OnWindowResize(int width, int height) override;

		glm::vec3 lightPosition;
		glm::vec3 lightDirection;
		unsigned int materialShininess;
		float materialKd;
		float materialKs;

		int isSpot = 0;
		float angle = 0;

		// in plus
		std::size_t gridPartitions;
		//typedef std::shared_ptr<glutil::Model> ModelPtr;
		glm::mat4 view;
		glm::mat4 proj;
		glm::vec3 viewPos;
		int maxHeight;
		
		glm::vec3 lightPos;
		//glm::vec3 lightDirection;
		glm::vec3 lightColor;
		glm::vec3 fogColor;
		GLfloat deltaTime = 0.0f;
		GLfloat lastFrame = 0.0f;

		//void makeAreas(const std::vector<Street>& v, const std::vector<Street>& h);
		void initializeAreaGrid();

		void makeBuilding(int areaIndex,int subAreaIndex,float x, float y, float height, float width, std::unordered_map<std::string, Mesh*>& meshes);
		void makeArea(int areaNr, float x, float z, float totalRadius, int fragments, std::unordered_map<std::string, Mesh*>& meshes);

		int numberOfBlocks[50][70]; //area, subarea => nof_blocks 
		//int buildingIndexes[50];
		int numberOfLayers[20][50][70]; // area, subarea, block => no_layer
		int buildingIndex = 0;

		Laborator::Camera *camera;
		glm::mat4 projectionMatrix;
		bool renderCameraTarget;
		std::unordered_map<std::string, Texture2D*> mapTextures;

		std::unordered_map<std::string, std::string> windowTexture;

		glm::mat4 roadModelMatrices[10][20]; // areas, subareas (fiecare 1 drum)
		glm::mat4 treeModelMatrix = glm::mat4(1);
		int areaNr = 0;
		int noFragments[100];
		bool isBridge[10][10];
		std::unordered_map<std::string, glm::mat4> bridgeMap;
		std::unordered_map<std::string, glm::vec3> lightMap;

		glm::mat4 upModelMatrix = glm::mat4(1);

		glm::mat4 skyModelMatrix = glm::mat4(1);

		glm::vec3 pointLightPositions[500];
		
		glm::mat4 testMatrix = glm::mat4(1);
		
		
};
