/*
#include "stdafx.h"
#include "Building.h"
#include "Ground.h"
#include "Random.h"
#include "Textures.h"
*/
#include "Tema3.h"
#include "Object2D.h"
#include "LabCamera.h"
#include "Random.h"

#include <Core/Engine.h>
#include <include/glm.h>

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>

using namespace std;

Tema3::Tema3()
{
}

Tema3::~Tema3()
{
}

float angleBetween(
	glm::vec3 a,
	glm::vec3 b,
	glm::vec3 origin
) {
	glm::vec3 da = glm::normalize(a - origin);
	glm::vec3 db = glm::normalize(b - origin);
	return glm::acos(glm::dot(da, db));
}

void Tema3::makeBuilding(int areaNr, int subArea, float x, float z, float width, float height,  std::unordered_map<std::string, Mesh*>& meshes) {

	std::cout << endl << "---> building subArea = " << subArea << endl;
	float areaRadius = width;// / 2;
	
	int numBlocks;

	//if (areaRadius < 6)
	numBlocks = Random::randomInt(3, 6);
	if(areaRadius > 1)
		numBlocks *= areaRadius;
	
	float currX = x;
	float currZ = z;

	float lastRadius = 0;

	int blockIndex = 0;
	//int decreaseDiameter
	numberOfBlocks[areaNr][subArea] = 0; // din cate corpuri turn va fi formata cladirea// trebuie intializate toate cu 0
	while (numberOfBlocks[areaNr][subArea] < numBlocks) {
		string windowTex = "window" + std::to_string(Random::random(1, 4));
		
		numberOfBlocks[areaNr][subArea]++;

		int fragments = Random::random(3, 7);
		numBlocks = Random::randomInt(3, 6);
		if (areaRadius > 1)
			numBlocks *= areaRadius;

		float restOfHeight = height; // inaltimea pe care o mai am de completat din corpul curent
		int layerIndex = 0;
		float bottom = 0;
		float radius = Random::randomFloat(0.3, 3);
		while(radius > areaRadius)
			radius = Random::randomFloat(0.3, areaRadius *0.6);
		if (subArea == 0 && radius > areaRadius / 5)
			radius /= 2; // daca este in centru ii micsorez latimea ptt ca in centru a  raza mai mare
		float deplasamentX = Random::randomFloat(0.1, areaRadius - radius);
		//float cosAlpha = deplasamentX / lastRadius ;
		//float deplasamentZ = deplasamentX * sinf(acos(cosAlpha));
		float deplasamentZ = Random::randomFloat(0.1, sqrt((areaRadius - radius) * (areaRadius - radius) - deplasamentX * deplasamentX));

		float signX = ((Random::random(0, 1) == 1) ? 1 : (-1));
		float signZ = Random::random(0, 1);
		currX = x + signX * deplasamentX;
		currZ = z + ((signZ == 1) ? 1 : (-1)) * deplasamentZ;

		std::cout << "blocIndex = " << blockIndex << endl;
		if (blockIndex > 0) { // daca nu este corpul principal
			float restOfHeight = Random::randomFloat(0.3, height);
			std::cout << "face deplasamentttttt last_radius=" << lastRadius << endl;
			
			if (blockIndex % 3 == 0) {
				restOfHeight = restOfHeight * 2 / 3;
			}
			else {
				//if (height > height*0.7)
					//restOfHeight = restOfHeight * 2;
			}	
		}
		/*
		if (radius > areaRadius / 3) {
			restOfHeight /= 2;
		}

		if (radius > areaRadius / 4 * 3) {
			areaRadius /= 2;
		}
		*/
		numberOfLayers[areaNr][subArea][blockIndex] = 0;
		/*
		//lumini 
		float increment = 2.0f * PI / fragments;
		float r = Random::random(0, fragments);
		float xLight = currX + radius * r * increment;
		float zLight = currZ + radius * r * increment;
		float yLight = Random::random(0.12, restOfHeight - 0.1);
		lightMap[std::to_string(areaNr) + 'a' + std::to_string(subArea) + "b" + std::to_string(blockIndex)] = glm::vec3(xLight, yLight, zLight);
		*/
		while (restOfHeight > 0) {
			numberOfLayers[areaNr][subArea][blockIndex]++;
			float currHeight = Random::randomFloat(0.3, restOfHeight);

			std::cout << " currHeight=" << currHeight << endl;
			string myId = std::to_string(areaNr) + 'a' + std::to_string(subArea) + "b" + std::to_string(blockIndex) + "l" + std::to_string(layerIndex);
			std::cout << myId << endl;

			//lumini 
			float increment = 2.0f * PI / fragments;
			float r = Random::random(0, fragments);
			float xLight = currX + radius * r * increment+ 0.01;
			float zLight = currZ + radius * r * increment + 0.01;
			float yLight = bottom + 0.95 * currHeight;// Random::random(bottom, bottom + currHeight);
			lightMap[myId] = glm::vec3(xLight, yLight, zLight);

			windowTexture[myId] = windowTex;

			// capac jos
			Mesh* down = Object2D::CreateCyrcle("down" + myId, radius, currX, currZ, bottom, fragments, glm::vec3(0, 0, 1), false);
			meshes[down->GetMeshID()] = down;

			// cilindru
			float unitWindow = Random::randomFloat(0.05, 0.5);
			Mesh* walls = Object2D::CreateCylinder("layer" + myId, radius, currX, currZ, fragments, bottom, 0.9 * currHeight, glm::vec3(0, 0, 1), 2, 2, unitWindow, 10);
			meshes[walls->GetMeshID()] = walls;
			// capac
			Mesh* top = Object2D::CreateCyrcle("top" + myId, radius, currX, currZ, bottom + 0.9 * currHeight, fragments, glm::vec3(0, 0, 1), false);
			meshes[top->GetMeshID()] = top;
			//cilindru
			Mesh* tier = Object2D::CreateCylinder("tier" + myId, 0.8 * radius, currX, currZ, fragments, bottom + 0.9 * currHeight, 0.1 * currHeight, glm::vec3(0, 0, 1), 2, 2, 0.1, 10);
			meshes[tier->GetMeshID()] = tier;
			//capac
			Mesh* top_tier = Object2D::CreateCyrcle("top_tier" + myId, 0.8 * radius, currX, currZ, bottom + currHeight, fragments, glm::vec3(0, 0, 1), false);
			meshes[top_tier->GetMeshID()] = top_tier;

			restOfHeight -= currHeight;
			bottom += currHeight;
			if (restOfHeight < 0.3)
				restOfHeight = 0;
			layerIndex++;
		}

		lastRadius = radius;
		std::cout << "no_layers=" << numberOfLayers[areaNr][subArea][blockIndex] << endl;
		blockIndex++;
	}
	std::cout << "no_blocks=" << numberOfBlocks[areaNr][subArea] << endl;
}

void Tema3::makeArea(int areaNr, float x, float z, float maxRadius, int fragments, std::unordered_map<std::string, Mesh*>& meshes) {
	float centerX = x, centerZ = z;
	float radiusInside = maxRadius;
	float radiusOutside = radiusInside + 0.2;
	//float fragments = Random::randomInt(5, 10);
	noFragments[areaNr] = fragments;
	float increment = 2.0f * PI / fragments;
	string areaId = std::to_string(areaNr);

	Mesh* strip = Object2D::CreatePolygonStrip("strip" + areaId + 'a' + std::to_string(0), radiusInside, radiusOutside, x, z, fragments, 0.09, 1, 1, 0.1, 10);
	meshes[strip->GetMeshID()] = strip;

	Mesh * area0 = Object2D::CreateCylinder("areaCilinder" + areaId + 'a' + std::to_string(0), radiusInside - 0.1,  x, z, fragments, 0, 0.11, glm::vec3(1, 1, 1), 1, 1, 0.01, 0);
	Mesh* area = Object2D::CreateCyrcle("area" + areaId + 'a' + std::to_string(0), radiusInside - 0.1, x, z, 0.11, fragments, glm::vec3(1, 1, 1), false);
	meshes[area->GetMeshID()] = area;
	meshes[area0->GetMeshID()] = area0;

	Mesh* sidewalk = Object2D::CreatePolygonStrip("sidewalk" + areaId + 'a' + std::to_string(0), radiusInside - 0.1, radiusInside, x, z, fragments, 0.09, 1, 1, 0.1, 10);
	meshes[sidewalk->GetMeshID()] = sidewalk;

	roadModelMatrices[areaNr][0] = glm::mat4(1);

	float radiusCercInscris = (radiusInside - 0.1) * cos(increment / 2); // 0.05 = trotuar => mai scad max pe care o taie un patrat din raza
	makeBuilding(areaNr, 0, x, z, radiusCercInscris, Random::randomFloat(3, 6), meshes);
	//glm::translate(treeModelMatrix, glm::vec3(x + radiusInside, 0, z));

	float lastRadiusInside = radiusInside;
	float lastRadiusOutside = radiusOutside;
	float lastIncrement = increment;
	int lastFragments = fragments;
	float oldX = x, oldZ = z;

	fragments = Random::randomInt(4, 8);
	increment = 2.0f * PI / fragments;

	radiusOutside = lastRadiusOutside * sin(lastIncrement / 2) / (1 - sin(lastIncrement / 2));
	radiusInside = radiusOutside - 0.2;

	float razaCentura = lastRadiusOutside + 2 * radiusInside;
	if (fragments % 2 == 1)
		razaCentura -= 0.1;

	Mesh * centura0= Object2D::CreateCylinder("centuraCilinder" + areaId, razaCentura + 0.3, x, z, 30, -1, 1.02, glm::vec3(1, 1, 1), 1, 1, 0.1, 0);
	Mesh* centura = Object2D::CreatePolygonStrip("centura" + areaId, razaCentura, razaCentura + 0.3, x, z, 30, 0.02, 1, 1, 0.1, 10);
	meshes[centura->GetMeshID()] = centura;
	meshes[centura0->GetMeshID()] = centura0;

	Mesh* borduraCentura = Object2D::CreatePolygonStrip("borduraCentura" + areaId, razaCentura + 0.3, razaCentura + 0.5, x, z, 30, 0, 1, 3, 0.2, 10);
	Mesh * borduraCentura0 = Object2D::CreateCylinder("borduraCilinder" + areaId, razaCentura + 0.5, x, z, 30, -1, 1, glm::vec3(1, 1, 1), 1, 1, 0.01, 0);
	meshes[borduraCentura->GetMeshID()] = borduraCentura;
	meshes[borduraCentura0->GetMeshID()] = borduraCentura0;

	Mesh* soil = Object2D::CreateCyrcle("soil" + areaId, razaCentura, x, z, 0.03, 30, glm::vec3(1, 1, 1), false);
	Mesh * soil0 = Object2D::CreateCylinder("soilCilinder" + areaId, razaCentura, x, z, 30, -0.5, 0.53, glm::vec3(1, 1, 1), 1, 1, 0.1, 0);
	meshes[soil->GetMeshID()] = soil;
	meshes[soil0->GetMeshID()] = soil0;

	for (int i = 0; i < lastFragments; i++) {
		x = oldX + radiusOutside + lastRadiusOutside - 0.2;// * (cos(lastIncrement * i));
		roadModelMatrices[areaNr][i + 1] = glm::mat4(1);

		roadModelMatrices[areaNr][i + 1] = glm::translate(roadModelMatrices[areaNr][i + 1], glm::vec3(x, 0, z));

		roadModelMatrices[areaNr][i + 1] = glm::translate(roadModelMatrices[areaNr][i + 1], glm::vec3(-(radiusOutside + lastRadiusOutside - 0.2), 0, 0));
		roadModelMatrices[areaNr][i + 1] = glm::rotate(roadModelMatrices[areaNr][i + 1], lastIncrement*i, glm::vec3(0, 1, 0));
		roadModelMatrices[areaNr][i + 1] = glm::translate(roadModelMatrices[areaNr][i + 1], glm::vec3(radiusOutside + lastRadiusOutside - 0.2, 0, 0));

		roadModelMatrices[areaNr][i + 1] = glm::rotate(roadModelMatrices[areaNr][i + 1], PI, glm::vec3(0, 1, 0));

		string myId = areaId + 'a' + std::to_string(i + 1);
		Mesh* strip1 = Object2D::CreatePolygonStrip("strip" + myId, radiusInside, radiusOutside, 0, 0, fragments, 0.07, 1, 1, 0.1, 10);
		meshes[strip1->GetMeshID()] = strip1;

		Mesh * area2 = Object2D::CreateCylinder("areaCilinder" + myId, radiusInside - 0.1, 0, 0, fragments, 0, 0.11, glm::vec3(1, 1, 1), 1, 1, 0.01, 0);
		Mesh* area1 = Object2D::CreateCyrcle("area" + myId, radiusInside - 0.1, 0, 0, 0.11, fragments, glm::vec3(1, 1, 1), false);
		meshes[area1->GetMeshID()] = area1;
		meshes[area2->GetMeshID()] = area2;

		Mesh * sidewalk2 = Object2D::CreateCylinder("sidewalkCilinder" + myId, radiusInside, 0, 0, fragments, 0, 0.09, glm::vec3(1, 1, 1), 1, 1, 0.01, 0);
		Mesh* sidewalk1 = Object2D::CreatePolygonStrip("sidewalk" + myId, radiusInside - 0.1, radiusInside, 0, 0, fragments, 0.09, 1, 1, 0.2, 10);
		meshes[sidewalk1->GetMeshID()] = sidewalk1;
		meshes[sidewalk2->GetMeshID()] = sidewalk2;

		radiusCercInscris = (radiusInside - 0.1) * cos(increment / 2);
		//radiusCercInscris = radiusCercInscris - radiusCercInscris * cos(increment / 2);
		makeBuilding(areaNr, i + 1, 0, 0, radiusCercInscris, Random::randomFloat(3,5), meshes);
	}
}

void Tema3::Init()

{
	camera = new Laborator::Camera();
	camera->Set(glm::vec3(0, 80, 80), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));
	
	string textureLoc = "textures/";

	Texture2D *texture = new Texture2D();
	texture->Load2D((textureLoc + "window8.jpg").c_str(), GL_REPEAT);
	mapTextures["window1"] = texture;

	Texture2D *texture1 = new Texture2D(); 
	texture1->Load2D((textureLoc + "road2.jpg").c_str(), GL_REPEAT);
	mapTextures["road2"] = texture1;

	Texture2D *texture2 = new Texture2D();
	texture2->Load2D((textureLoc + "water2.jpg").c_str(), GL_REPEAT);
	mapTextures["grass"] = texture2;

	Texture2D *grass2 = new Texture2D();
	grass2->Load2D((textureLoc + "grass2.jpg").c_str(), GL_REPEAT);
	mapTextures["grass2"] = grass2;

	Texture2D *texture3 = new Texture2D();
	texture3->Load2D((textureLoc + "sidewalk4.jpg").c_str(), GL_REPEAT);
	mapTextures["sidew1"] = texture3;

	Texture2D *texture4 = new Texture2D();
	texture4->Load2D((textureLoc + "sidewalk4.jpg").c_str(), GL_REPEAT);
	mapTextures["sidew1"] = texture4;

	Texture2D *texture5 = new Texture2D();
	texture5->Load2D((textureLoc + "window12.jpg").c_str(), GL_REPEAT);
	mapTextures["window2"] = texture5;

	Texture2D *texture6 = new Texture2D();
	texture6->Load2D((textureLoc + "window14.jpg").c_str(), GL_REPEAT);
	mapTextures["window3"] = texture6;

	Texture2D *texture7 = new Texture2D();
	texture7->Load2D((textureLoc + "window14.jpg").c_str(), GL_REPEAT);
	mapTextures["window3"] = texture7;

	Texture2D *up = new Texture2D();
	up->Load2D((textureLoc + "water1.jpg").c_str(), GL_MIRRORED_REPEAT);
	mapTextures["up"] = up;

	Texture2D *sky = new Texture2D();
	sky->Load2D((textureLoc + "panorama2.jpg").c_str(), GL_REPEAT);
	mapTextures["sky"] = sky;

	Texture2D *ground = new Texture2D();
	ground->Load2D((textureLoc + "water.jpg").c_str(), GL_REPEAT);
	mapTextures["ground"] = sky;


	float boxLength = 600;
	{
		Mesh* mesh = new Mesh("sky");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
		skyModelMatrix = glm::translate(skyModelMatrix, glm::vec3(0, 20, 0));
		skyModelMatrix = glm::scale(skyModelMatrix,glm::vec3( 300, 200, 300));
	}
	
	// initializeaza ground
	Mesh* top = Object2D::CreateQuad("up", glm::vec3(0, 0, 0), boxLength, boxLength, glm::vec3(1,1,1), 1, 1, 20, false);
	meshes[top->GetMeshID()] = top;
	upModelMatrix = glm::translate(upModelMatrix, glm::vec3(-(boxLength / 2), -0.5, (boxLength / 2)));
	upModelMatrix = glm::rotate(upModelMatrix, -(PI /2), glm::vec3(1, 0, 0));
	
	///////////////////////////////////////////////////////////////////
	// face o arie mare cu mai multe arii mici

	float x = 0, z = 0;
	//float centerX = x, centerZ = z; 
	float centralRadius = Random::randomFloat(2, 5);
	float centralFragments = Random::randomInt(7, 10);
	float increment = 2.0f * PI / centralFragments;
	makeArea(areaNr, x, z, centralRadius, centralFragments, meshes);
	areaNr++;
	centralRadius += centralRadius * sin(increment / 2) / (1 - sin(increment / 2)) + 1.1; //cu tot cu subariile
	//for (float currAngle = 0.0f; currAngle <= 2.0f * PI; currAngle += increment)
	
	float currAngle = 0.0;
	float lastIncrement = -1;
	float lastRadius = 0;
	float lastX = -1000, lastZ =-1000;

	while (currAngle < 1.7f * PI)
	{
		float d = Random::randomFloat(centralRadius*2, 25);
		float xCoord = d * cos(currAngle) + x;
		float zCoord = d * sin(currAngle) + z;
		
		int fragments = Random::random(5, 10);
		float newIncrement = 2.0f * PI / fragments;

		float maxRadius = d - centralRadius ; // am grija sa nu se suprapuna cu centrul
		if (lastIncrement != 0) {
			//nu e prima iteratie => trebuie sa am grijasa nu se suprapuna cu cea anterioara
			// am nevoie de ambele conditii =>> fac minimul
			if(((2 * centralRadius * sin(lastIncrement/2)) - lastRadius) < maxRadius)
				maxRadius = 2 * centralRadius * sin(lastIncrement / 2) - lastRadius;
		}
		
		float radius = Random::randomFloat(3, 7);
		if (radius > maxRadius)
			radius = maxRadius;
		float newCircleTotalRadius = radius;
		radius = radius / (1 + sin(newIncrement / 2) / (1 - sin(newIncrement / 2))) - 1.1;
		
		if (radius < 2) {
			radius = 2;
		}
		
		makeArea(areaNr, xCoord, zCoord, radius, fragments, meshes);

		// fa drum de la centru la area noua
		string name = "bridge" + std::to_string(0) + "to" + std::to_string(areaNr);
		Mesh *bridge = new Mesh(name);

		bridge = Object2D::CreateQuad(name, glm::vec3(0,-1,0), d, 2, glm::vec3(1,1,1), 1, 4, 0.2, false);
		meshes[bridge->GetMeshID()] = bridge;

		bridgeMap[name] = glm::mat4(1);
		float xmid = (x + xCoord) / 2;
		float zmid = (z + zCoord) / 2;

		bridgeMap[name] = glm::translate(bridgeMap[name], glm::vec3(0, 0.01, 0));
		bridgeMap[name] = glm::rotate(bridgeMap[name], -currAngle , glm::vec3(0, 1, 0));
		bridgeMap[name] = glm::rotate(bridgeMap[name], PI/2, glm::vec3(1, 0, 0));
	
		isBridge[0][areaNr] = true;
		
		if (lastX != -1000 && currAngle < 3 * PI/4) { // face drum intre ariile din jur
			std::cout << " ===========FACE muchiile========" << endl;
		
			float length = glm::distance(glm::vec3(lastX, 0, lastZ), glm::vec3(xCoord, 0, zCoord));
			float angle = angleBetween( glm::vec3(lastX + 1, 0, lastZ), glm::vec3(xCoord, 0, zCoord),glm::vec3(lastX, 0, lastZ));
			//if (lastX > 0 && lastZ > 0)
				//angle = (2 * PI - angle);

			string name1 = "bridge" + std::to_string(areaNr - 1) + "to" + std::to_string(areaNr);
			Mesh *bridge1 = new Mesh(name1);
			bridge1 = Object2D::CreateQuad(name1, glm::vec3(0, -1, 0), length, 2, glm::vec3(1, 1, 1), 1, 5, 0.01, false);
			meshes[bridge1->GetMeshID()] = bridge1;

			bridgeMap[name1] = glm::mat4(1);
			bridgeMap[name1] = glm::translate(bridgeMap[name1], glm::vec3(lastX, 0.07, lastZ));
			bridgeMap[name1] = glm::rotate(bridgeMap[name1], angle, glm::vec3(0, 1, 0));
			bridgeMap[name1] = glm::rotate(bridgeMap[name1], PI / 3, glm::vec3(1, 0, 0));

			isBridge[areaNr - 1][areaNr] = false;
		}
		
		areaNr++;
		lastRadius = maxRadius;
		lastIncrement = Random::random(1, centralFragments / 3) * increment;
		currAngle += lastIncrement;
		lastX = xCoord;
		lastZ = zCoord;

		
		
	}

	{
		Mesh* bridge = new Mesh("bridge");
		bridge->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "Toilet.obj");
		meshes[bridge->GetMeshID()] = bridge;
	}
	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	// Create a shader program for drawing face polygon with the color of the normal
	{
		Shader *shader = new Shader("ShaderLab8");
		shader->AddShader("Source/Laboratoare/Tema3/Shaders/VertexShader8.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Tema3/Shaders/FragmentShader8.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	{
		Shader *shader = new Shader("MainShader");
		shader->AddShader("Source/Laboratoare/Tema3/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Tema3/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	//Light & material properties
	{
		lightPosition = glm::vec3(0, -0.2, 0);
		lightDirection = glm::vec3(0, 1, 0);
		materialShininess = 30;
		materialKd = 3.5;
		materialKs = 3;
		angle = 0;
	}

	worldWidth = 30;
	worldHeight = 30;
	std::cout << "world height " << worldHeight << endl;

	projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);

	testMatrix = glm::mat4(1);
	testMatrix = glm::scale(testMatrix, glm::vec3(500, 500, 500));
	testMatrix = glm::translate(testMatrix, glm::vec3(0, 20, 0));
}

void Tema3::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);	
}

void Tema3::Update(float deltaTimeSeconds)
{
		// floor
	RenderSimpleMesh(meshes["bridge"], shaders["ShaderLab8"], testMatrix, glm::vec3(1, 1, 1), mapTextures["road2"], 0, 0, std::to_string(0));
		
		//modelMatrix1 = glm::translate(modelMatrix1, glm::vec3(0, 0, 0));
		//RenderSimpleMesh(meshes["tree"], shaders["ShaderLab8"], treeModelMatrix,glm::vec3(0.6,0.7,0.2), mapTextures["grass"]);
		
		glm::mat4 modelMatrix = glm::mat4(1);
		for (int areaIndex = 0; areaIndex < areaNr; areaIndex++) {

			RenderSimpleMesh(meshes["centura" + std::to_string(areaIndex)], shaders["ShaderLab8"], modelMatrix, glm::vec3(1, 1, 1), mapTextures["road2"], 0, 0, std::to_string(0));
			RenderSimpleMesh(meshes["centuraCilinder" + std::to_string(areaIndex)], shaders["ShaderLab8"], modelMatrix, glm::vec3(1, 1, 1), mapTextures["road2"], 0, 0, std::to_string(0));
			RenderSimpleMesh(meshes["borduraCentura" + std::to_string(areaIndex)], shaders["ShaderLab8"], modelMatrix, glm::vec3(1, 1, 1), mapTextures["sidew1"], 0, 0, std::to_string(0));
			RenderSimpleMesh(meshes["borduraCilinder" + std::to_string(areaIndex)], shaders["ShaderLab8"], modelMatrix, glm::vec3(1, 1, 1), mapTextures["sidew1"], 0, 0, std::to_string(0));
			RenderSimpleMesh(meshes["soil" + std::to_string(areaIndex)], shaders["ShaderLab8"], modelMatrix, glm::vec3(1, 1, 1), mapTextures["grass"], 0, 0, std::to_string(0));
			RenderSimpleMesh(meshes["soilCilinder" + std::to_string(areaIndex)], shaders["ShaderLab8"], modelMatrix, glm::vec3(1, 1, 1), mapTextures["grass"], 0, 0, std::to_string(0));

			for (int i = 0; i < noFragments[areaIndex] + 1; i++) {
				string myId = std::to_string(areaIndex) + 'a' + std::to_string(i);
				RenderSimpleMesh(meshes["strip" + myId], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures["road2"], 0, 0, std::to_string(0));
				RenderSimpleMesh(meshes["area" + myId], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures["grass"], 0, 0, "");
				RenderSimpleMesh(meshes["areaCilinder" + myId], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures["grass"], 0, 0, std::to_string(0));
				RenderSimpleMesh(meshes["sidewalk" + myId], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures["sidew1"], 0, 0, std::to_string(0));
				RenderSimpleMesh(meshes["sidewalkCilinder" + myId], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures["sidew1"], 0, 0, std::to_string(0));

				
				for (int blockIndex = 0; blockIndex < numberOfBlocks[areaIndex][i]; blockIndex++) {

					for (int layerIndex = 0; layerIndex < numberOfLayers[areaIndex][i][blockIndex]; layerIndex++) {
						string id = std::to_string(areaIndex) + 'a' + std::to_string(i) + "b" + std::to_string(blockIndex) + "l" + std::to_string(layerIndex);
						//string lid = std::to_string(areaIndex) + 'a' + std::to_string(i) + "b" + std::to_string(blockIndex);
						RenderSimpleMesh(meshes["down" + id], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures[windowTexture[id]], 0, 1, id);
						RenderSimpleMesh(meshes["layer" + id], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures[windowTexture[id]], 0, 1, id);
						RenderSimpleMesh(meshes["top" + id], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures[windowTexture[id]], 0, 1, id);
						RenderSimpleMesh(meshes["tier" + id], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures[windowTexture[id]], 0, 1, id);
						RenderSimpleMesh(meshes["top_tier" + id], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures[windowTexture[id]], 0, 1, id);
					}
					string id = std::to_string(areaIndex) + 'a' + std::to_string(i) + "b" + std::to_string(blockIndex);
					//RenderSimpleMesh(meshes["down" + id], shaders["ShaderLab8"], roadModelMatrices[areaIndex][i], glm::vec3(1, 1, 1), mapTextures[windowTexture[id]], 0, 1, id);
				}
			}
		}
		//sky
		RenderSimpleMesh(meshes["up"], shaders["ShaderLab8"], upModelMatrix, glm::vec3(1, 1, 1), mapTextures["up"],0, 0, std::to_string(0));
		RenderSimpleMesh(meshes["sky"], shaders["ShaderLab8"], skyModelMatrix, glm::vec3(1, 1, 1), mapTextures["sky"],1, 0, std::to_string(0));
		
		for (int i = 0; i < areaNr; i++) {
			for (int j = 0; j < areaNr; j++) {
				if (isBridge[i][j] == true) {
					string name = "bridge" + std::to_string(i) + "to" + std::to_string(j);
					RenderSimpleMesh(meshes[name], shaders["ShaderLab8"], bridgeMap[name], glm::vec3(1, 1, 1), mapTextures["sidew1"],0, 0, std::to_string(0));
				}
			}
		}
		
		//name = "bridge" + std::to_string(0) + "to" + std::to_string(3);
		//RenderSimpleMesh(meshes[name], shaders["ShaderLab8"], bridgeMap[name], glm::vec3(1, 1, 1), mapTextures["road2"]);
		//string name = "bridge" + std::to_string(0) + "to" + std::to_string(1);
		//RenderSimpleMesh(meshes[name], shaders["ShaderLab8"], bridgeMap[name], glm::vec3(1, 1, 1), mapTextures["road2"]);

	
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 1, 0));
		RenderSimpleMesh(meshes["sphere"], shaders["ShaderLab8"], modelMatrix, glm::vec3(1, 1, 1), mapTextures["sidew1"], 0, 0, std::to_string(0));
	}
	/*
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(2, 0.5f, 0));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(60.0f), glm::vec3(1, 0, 0));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f));
		RenderSimpleMesh(meshes["box"], shaders["ShaderLab8"], modelMatrix);
	}
	*/
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-2, 0.5f, 0));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(60.0f), glm::vec3(1, 1, 0));
		RenderSimpleMesh(meshes["box"], shaders["ShaderLab8"], modelMatrix, glm::vec3(0, 0.5, 0), mapTextures["sidew1"] ,0, 0, std::to_string(0));
	}
	
	
	// Render the point light in the scene
	
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, lightPosition);
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.1f));
		RenderMesh(meshes["sphere"], shaders["Simple"], modelMatrix);
	}
}

void Tema3::FrameEnd()
{
	//DrawCoordinatSystem();
}

//RenderSimpleMesh(meshes["bridge"], shaders["ShaderLab8"], testMatrix, glm::vec3(1, 1, 1), mapTextures["road2"], 0, 0, "");
void Tema3::RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 & modelMatrix, const glm::vec3 &color, Texture2D* texture1, int sky, int building, std::string name)
{
	if (!mesh || !shader || !shader->GetProgramID()) {
		/*
		if(!mesh)
			cout << "mesh" << endl;
		if (!shader)
			cout << "shader" << endl;
		if (!shader->GetProgramID())
			cout << "!shader->GetProgramID()" << endl;
		*/
		return;
	}
		

	// render an object using the specified shader and the specified position
	glUseProgram(shader->program);

	// Set shader uniforms for light & material properties
	// TODO: Set light position uniform
	int light_position = glGetUniformLocation(shader->program, "light_position");
	glUniform3f(light_position, lightPosition.x, lightPosition.y, lightPosition.z);

	int light_direction = glGetUniformLocation(shader->program, "light_direction");
	glUniform3f(light_direction, lightDirection.x, lightDirection.y, lightDirection.z);

	glm::vec3 sp = glm::vec3(1);
	glm::vec3 sd = glm::vec3(1);
	if (building == 1) {
		sp = lightMap[name];
		int dir = Random::random(0, 1);
		if (dir == 0)
			dir = -1;
		glm::vec3 sd = glm::vec3(0, dir, 0);
	}
	int spot_position = glGetUniformLocation(shader->program, "spot_position");
	glUniform3f(spot_position, sp.x, sp.y, sp.z);

	int spot_direction = glGetUniformLocation(shader->program, "spot_direction");
	glUniform3f(spot_direction, sd.x, sd.y, sd.z);
	
	//spot
	int isSpot_location = glGetUniformLocation(shader->program, "isSpot");
	glUniform1i(isSpot_location, isSpot);

	int isSky_location = glGetUniformLocation(shader->program, "isSky");
	glUniform1i(isSky_location, sky);

	int isBuilding_location = glGetUniformLocation(shader->program, "isBuilding");
	glUniform1i(isBuilding_location, building);

	//unghi
	int angle_location = glGetUniformLocation(shader->program, "angle");
	glUniform1f(angle_location, angle);

	// TODO: Set eye position (camera position) uniform
	glm::vec3 eyePosition = GetSceneCamera()->transform->GetWorldPosition();
	int eye_position = glGetUniformLocation(shader->program, "eye_position");
	glUniform3f(eye_position, eyePosition.x, eyePosition.y, eyePosition.z);

	// TODO: Set material property uniforms (shininess, kd, ks, object color) 
	int material_shininess = glGetUniformLocation(shader->program, "material_shininess");
	glUniform1i(material_shininess, materialShininess);

	int material_kd = glGetUniformLocation(shader->program, "material_kd");
	glUniform1f(material_kd, materialKd);

	int material_ks = glGetUniformLocation(shader->program, "material_ks");
	glUniform1f(material_ks, materialKs);

	int object_color = glGetUniformLocation(shader->program, "object_color");
	glUniform3f(object_color, color.r, color.g, color.b);

	// Bind model matrix
	GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	// Bind view matrix
	glm::mat4 viewMatrix = GetSceneCamera()->GetViewMatrix();
	int loc_view_matrix = glGetUniformLocation(shader->program, "View");
	glUniformMatrix4fv(loc_view_matrix, 1, GL_FALSE, glm::value_ptr(viewMatrix));

	// Bind projection matrix
	glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
	int loc_projection_matrix = glGetUniformLocation(shader->program, "Projection");
	glUniformMatrix4fv(loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

	
	if (texture1)
	{
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture1->GetTextureID());
		glUniform1i(glGetUniformLocation(shader->program, "texture_1"), 0);
	}
	// Draw the object
	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);
}



// Documentation for the input functions can be found in: "/Source/Core/Window/InputController.h" or
// https://github.com/UPB-Graphics/Framework-EGC/blob/master/Source/Core/Window/InputController.h

void Tema3::OnInputUpdate(float deltaTime, int mods)
{
	float speed = 10;
	glm::vec3 up = glm::vec3(0, 1, 0);
	glm::vec3 right = GetSceneCamera()->transform->GetLocalOXVector();
	glm::vec3 forward = GetSceneCamera()->transform->GetLocalOZVector();
	forward = glm::normalize(glm::vec3(forward.x, 0, forward.z));

	
	if (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{

		// Control light position using on W, A, S, D, E, Q
		if (window->KeyHold(GLFW_KEY_W)) lightPosition -= forward * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_A)) lightPosition -= right * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_S)) lightPosition += forward * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_D)) lightPosition += right * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_E)) lightPosition += up * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_Q)) lightPosition -= up * deltaTime * speed;
	}
	
	if (window->KeyHold(GLFW_KEY_O)) {
		angle += RADIANS(5) * deltaTime;
	}

	if (window->KeyHold(GLFW_KEY_P)) {
		angle -= RADIANS(5) * deltaTime;
	}

	if (window->KeyHold(GLFW_KEY_UP)) {
		lightDirection -= forward * deltaTime * speed;
	}

	if (window->KeyHold(GLFW_KEY_DOWN)) {
		lightDirection -= right * deltaTime * speed;
	}

	lightDirection /= sqrt(lightDirection.x * lightDirection.x + lightDirection.y * lightDirection.y + lightDirection.z * lightDirection.z);
	
}

void Tema3::OnKeyPress(int key, int mods)
{
	// add key press event
	
		if(window->KeyHold(GLFW_KEY_F)) {
			isSpot = (isSpot + 1) % 2;
		}
	
}

void Tema3::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Tema3::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void Tema3::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Tema3::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Tema3::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema3::OnWindowResize(int width, int height)
{
}
