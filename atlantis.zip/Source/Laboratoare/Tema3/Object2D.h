#pragma once

#include <string>

#include <include/glm.h>
#include <Core/GPU/Mesh.h>

#include "Tema3.h";

namespace Object2D
{
	// Create square with given bottom left corner, length and color
	Mesh* CreateSquare(std::string name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill = false);
	Mesh* CreateRectangle(std::string name, glm::vec3 leftBottomCorner, float length, float height, glm::vec3 color, bool fill = false);
	Mesh* CreateBrick(std::string name, glm::vec3 leftBottomCorner, float length, float height, glm::vec3 color, bool fill);
	Mesh* CreateCyrcle(std::string name, float radius, float x, float y, float z, int fragments, glm::vec3 color, bool fill);
	Mesh* MakeGrid(std::string name, glm::vec3 leftBottomCorner, const glm::vec3& d1, const glm::vec3& d2, const glm::vec3& normal,
		int width, int height);
	Mesh* CreatePolygonStrip(std::string name, float radiusInside, float radiusOutside, float x, float z, int fragments, float bottom, int horizontal_reps, int vertical_reps, float unit, float anomaly);
	Mesh* CreateQuad(std::string name, glm::vec3 leftBottomCorner, float length, float height, glm::vec3 color, int horizontal_reps, int vertical_reps, float unit, bool fill);
	
	Mesh* CreateCylinder(std::string name, float radius, float x, float y, int fragments, float bottom, float height, glm::vec3 color, int horizontal_reps, int vertical_reps, float unit, float anomaly);
}

