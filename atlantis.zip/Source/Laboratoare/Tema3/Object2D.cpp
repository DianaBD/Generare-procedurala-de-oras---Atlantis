#include "Object2D.h"

#include <Core/Engine.h>
#include "Tema3.h";
#include <iostream>

using namespace std;

Mesh* Object2D::MakeGrid(std::string name, glm::vec3 leftBottomCorner, const glm::vec3& d1, const glm::vec3& d2, const glm::vec3& normal,
	int width, int height)
{
	std::vector<VertexFormat> vertices;
	std::vector<unsigned short> indices;

	glm::vec3 downCorner;
	glm::vec3 topCorner;

	glm::vec3 downCornerRef = leftBottomCorner;
	glm::vec3 topCornerRef = leftBottomCorner + d2;

	glm::vec3 color = glm::vec3(0, 0.5, 0.8);
	int i = 0;
	
	// center x,z on origin
	float vSize = 5;
	float offset = (float)width / 2.0f, scale = (float)width / (float)vSize;

	// create local vertices
	cout << endl << "vertecsi:" << endl;
	for (uint z = 0; z < vSize; z++) {
		for (uint x = 0; x < vSize; x++) {
			uint index = x + (z * vSize);
			vertices.emplace(vertices.begin() + index,VertexFormat(glm::vec3((scale*(float)x) - offset,
				5,
				(scale*(float)z) - offset)
				, color));
			cout << index << ": " << (scale * (float)x) - offset << " " << ((scale*(float)z) - offset) << endl;
		}
	}

	// create local indices
	//var indices = new System.Collections.Generic.List<IndexType>();
	cout <<endl << "indici:" << endl;
	for (int z = 0; z < vSize - 1; z++) {
		// degenerate index on non-first row
		if (z != 0) {
			indices.push_back(z * vSize);
			cout << z * vSize << endl;
		}
		// main strip
		for (int x = 0; x < vSize; x++) {
			indices.push_back(z * vSize + x);
			indices.push_back((z + 1) * vSize + x);
			cout << z * vSize + x << endl;
			cout << (z + 1) * vSize + x << endl;
		}

		// degenerate index on non-last row
		if (z != (vSize - 2)) {
			indices.push_back((z + 1) * vSize + (vSize - 1));
			cout << (z + 1) * vSize + (vSize - 1) << endl;
		}
	}

	Mesh* grid = new Mesh(name);
	grid->SetDrawMode(GL_LINE_LOOP);
	/*
	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}
	*/
	grid->InitFromData(vertices, indices);
	return grid;
}
Mesh* Object2D::CreateSquare(std::string name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill)
{
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices =
	{
		VertexFormat(corner, color, glm::vec3(1, 0, 0), glm::vec2(0,0)),
		VertexFormat(corner + glm::vec3(length, 0, 0), color, glm::vec3(0, 1, 0), glm::vec2(0,1)),
		VertexFormat(corner + glm::vec3(length, length, 0), color, glm::vec3(0, 1, 0), glm::vec2(1,1)),
		VertexFormat(corner + glm::vec3(0, length, 0), color, glm::vec3(0, 1, 0), glm::vec2(1,0))
	};

	Mesh* square = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 2, 3 };
	
	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;
}

Mesh* Object2D::CreateQuad(std::string name, glm::vec3 leftBottomCorner, float length, float height, glm::vec3 color, int horizontal_reps, int vertical_reps, float unit, bool fill)
{
	glm::vec3 corner = leftBottomCorner;

	//////
	vector<glm::vec3> vertices
	{
		glm::vec3(corner + glm::vec3(length, height, 0)),	// Top Right
		glm::vec3(corner + glm::vec3(length, 0, 0)),	// Bottom Right

		glm::vec3(corner + glm::vec3(0, height, 0)),	// Top Left
		glm::vec3(corner),	// Bottom Left
		
	};

	vector<glm::vec3> normals
	{
		glm::vec3(0, 1, 1),
		glm::vec3(1, 0, 1),
		glm::vec3(0, 1, 0),
		glm::vec3(1, 0, 0)
	};

	// TODO : Complete texture coordinates for the square
	float horiz = 0, vertical = 0;
	if (unit == 0) {
		horiz = horizontal_reps;
		vertical = vertical_reps;
	}
	else {
		horiz = length / unit;
		vertical = height / unit;
	}
	vector<glm::vec2> textureCoords
	{
		glm::vec2(0.0f, vertical),
		glm::vec2(0.0f, 0.0f),

		glm::vec2(horiz,vertical),
		glm::vec2(horiz, 0.0f),
		
	};

	vector<unsigned short> indices =
	{
		0, 1, 2,
		1, 3, 2
	};

	Mesh* mesh = new Mesh(name);
	mesh->InitFromData(vertices, normals, textureCoords, indices);
	return mesh;
}

Mesh* Object2D::CreateRectangle(std::string name, glm::vec3 leftBottomCorner, float length, float height, glm::vec3 color, bool fill)
{
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices =
	{
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(length, 0, 0), color),
		VertexFormat(corner + glm::vec3(length, height, 0), color),
		VertexFormat(corner + glm::vec3(0, height, 0), color)
	};

	Mesh* square = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 2, 3 };

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;
}

//std::vector<Vertex> CreateCircleArray(float radius, float x, float y, int fragments)
Mesh* Object2D::CreateCyrcle(std::string name, float radius, float x, float z, float y, int fragments, glm::vec3 color, bool fill)
{
	const float PI = 3.1415926f;

	std::vector<glm::vec3> vertices;
	std::vector<unsigned short> indices;
	std::vector<glm::vec3> normals;
	std::vector<glm::vec2> textureCoords;

	float increment = 2.0f * PI / fragments;
	
	vertices.push_back(glm::vec3(x, y, z));
	indices.push_back(0);
	normals.push_back(glm::vec3(0, 1, 1));
	textureCoords.push_back(glm::vec2(0.0f, 1));

	Mesh* circle = new Mesh(name);

	int i = 1;
	for (float currAngle = 0.0f; currAngle <= 2.0f * PI; currAngle += increment)
	{
		vertices.push_back(glm::vec3(radius * cos(currAngle) + x, y, radius * sin(currAngle) + z));
		normals.push_back(glm::vec3(0, 1, 1));
		textureCoords.push_back(glm::vec2(0.0f, 1));
		
		if (i != 1) {
			indices.push_back(i);
			indices.push_back(0);
			indices.push_back(i);
		}
		else
			indices.push_back(i);
		i++;
	}
	indices.push_back(1);


	for (float currAngle = 0.0f; currAngle <= 2.0f * PI; currAngle += increment) {
		float width = increment;
	}

	circle->InitFromData(vertices, normals, textureCoords, indices);
	return circle;
}
Mesh* Object2D::CreatePolygonStrip(std::string name, float radiusInside, float radiusOutside, float x, float z, int fragments, float bottom, int horizontal_reps, int vertical_reps, float unit, float anomaly)
{
	const float PI = 3.1415926f;

	std::vector<glm::vec3> vertices;
	std::vector<unsigned short> indices;
	std::vector<glm::vec3> normals;
	std::vector<glm::vec2> textureCoords;

	float increment = 2.0f * PI / fragments;

	int horiz = 0, vertical = 0;
	if (unit == 0) {
		horiz = horizontal_reps;
		vertical = vertical_reps;
	}
	else {/*
		horiz = (radius*sinf(increment) * 2) / unit;
		vertical = height / unit;
		*/
	}
	horiz = (radiusInside * sinf(increment) * 2) / unit;
	vertical = vertical_reps;
	int i = 0;
	//i++;
	// daca sari cu incrementul seschimba forma
	anomaly = 3;
	int last = 0, both = 0, first = 0;
	int anomaly_type = 3; //aplatizeaza forma
	for (float currAngle = 0.0f; currAngle < 2.0f * PI; currAngle += increment)
	{
		glm::vec3 corner1;
		glm::vec3 corner2;
		glm::vec3 corner3;
		glm::vec3 corner4;

		float nextAngle = currAngle + increment;

		corner1 = glm::vec3(radiusOutside * cos(currAngle) + x, bottom, radiusOutside * sin(currAngle) + z);
		corner2 = glm::vec3(radiusInside * cos(currAngle) + x, bottom, radiusInside * sin(currAngle) + z);
		corner3 = glm::vec3(radiusOutside * cos(nextAngle) + x, bottom, radiusOutside * sin(nextAngle) + z);
		corner4 = glm::vec3(radiusInside * cos(nextAngle) + x, bottom, radiusInside * sin(nextAngle) + z);


		//////
		vertices.push_back(glm::vec3(corner1));	// Top Right
		vertices.push_back(glm::vec3(corner2));	// Bottom Right
		vertices.push_back(glm::vec3(corner3));	// Top Left
		vertices.push_back(glm::vec3(corner4));	// Bottom Left

		/*
		normals.push_back(glm::vec3(0, 1, 1));
		normals.push_back(glm::vec3(1, 0, 1));
		normals.push_back(glm::vec3(0, 1, 0));
		normals.push_back(glm::vec3(1, 0, 0));
		*/
		normals.push_back(glm::vec3(0, 1, 0));
		normals.push_back(glm::vec3(0, 1, 0));
		normals.push_back(glm::vec3(0, 1, 0));
		normals.push_back(glm::vec3(0, 1, 0));

		// TODO : Complete texture coordinates for the square


		textureCoords.push_back(glm::vec2(0.0f, vertical));
		textureCoords.push_back(glm::vec2(0.0f, 0.0f));
		textureCoords.push_back(glm::vec2(horiz, vertical));
		textureCoords.push_back(glm::vec2(horiz, 0.0f));

		indices.push_back(i);
		indices.push_back(i + 1);
		indices.push_back(i + 2);
		indices.push_back(i + 1);
		indices.push_back(i + 3);
		indices.push_back(i + 2);

		i += 4;


	}

	//indices.push_back(1);
	Mesh* cylinder = new Mesh(name);
	cylinder->InitFromData(vertices, normals, textureCoords, indices);
	return cylinder;

	return NULL;
}
Mesh* Object2D::CreateCylinder(std::string name, float radius, float x, float z, int fragments, float bottom, float height, glm::vec3 color, int horizontal_reps, int vertical_reps, float unit, float anomaly)
{
	const float PI = 3.1415926f;

	std::vector<glm::vec3> vertices;
	std::vector<unsigned short> indices;
	std::vector<glm::vec3> normals;
	std::vector<glm::vec2> textureCoords;

	float increment = 2.0f * PI / fragments;

	int horiz = 0, vertical = 0;
	if (unit == 0) {
		horiz = horizontal_reps;
		vertical = vertical_reps;
	}
	else {
		horiz = (radius*sinf(increment) * 2) / unit;
		vertical = height / unit;
	}
	
	int i = 0;
	//i++;
	// daca sari cu incrementul seschimba forma
	anomaly = 3;
	int last = 0, both = 0, first = 0;
	int anomaly_type = 3; //aplatizeaza forma
	for (float currAngle = 0.0f; currAngle < 2.0f * PI; currAngle += increment)
	{
		glm::vec3 corner1;
		glm::vec3 corner2;

		float nextAngle = currAngle + increment;
		
		corner1 = glm::vec3(radius * cos(currAngle) + x , bottom, radius * sin(currAngle) + z);
		corner2 = glm::vec3(radius * cos(nextAngle) + x , bottom, radius * sin(nextAngle) + z);
		
		
		//////
		vertices.push_back(glm::vec3(corner1 + glm::vec3(0, height, 0)));	// Top Right
		vertices.push_back(glm::vec3(corner1 + glm::vec3(0, 0, 0)));	// Bottom Right
		vertices.push_back(glm::vec3(corner2 + glm::vec3(0, height, 0)));	// Top Left
		vertices.push_back(glm::vec3(corner2));	// Bottom Left
		
		normals.push_back(glm::vec3(0, 1, 1));
		normals.push_back(glm::vec3(1, 0, 1));
		normals.push_back(glm::vec3(0, 1, 0));
		normals.push_back(glm::vec3(1, 0, 0));
		
		// TODO : Complete texture coordinates for the square
		
		textureCoords.push_back(glm::vec2(0.0f, vertical));
		textureCoords.push_back(glm::vec2(0.0f, 0.0f));
		textureCoords.push_back(glm::vec2(horiz, vertical));
		textureCoords.push_back(glm::vec2(horiz, 0.0f));
		
		indices.push_back(i);
		indices.push_back(i + 1);
		indices.push_back(i + 2);
		indices.push_back(i + 1);
		indices.push_back(i + 3);
		indices.push_back(i + 2);
		
		i += 4;


	}
	
	//indices.push_back(1);
	Mesh* cylinder = new Mesh(name);
	cylinder->InitFromData(vertices, normals, textureCoords, indices);
	return cylinder;
	
	return NULL;
}

