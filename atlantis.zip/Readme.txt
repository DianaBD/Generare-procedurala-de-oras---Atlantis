336CA Brodoceanu Diana

     Readme - Tema3 - EGC

    O zona reprezinta un poligon de raza aleatoare orizontal cu 4,5,6.. 8 laturi. In fiecare
varf al acestuia se afla un alt poligon cu nr aleator de laturi si raza calculata pe baza razei 
si a nr de laturi ale poligolului central. De-a lungul laturilor tuturor 
acestor poligoane am amplasat strazi.
    Orasul este format dintr-o zona centrala, in jurul careia am amplasat random
alte zone pe care le-am unit cu poduri de cea centrala.
    Fiecare zona are in centru un cluster de cladiri compuse din mai multe corpuri,
fiecare corp compus la randul sau din mai multe layere de inatltimi si
diametru pseudo-aletor alese.
    Un layer al unui corp este format dintr-un 
       - poligon -> baza
       - cilindru cu acelasi nr de laturi ca baza 
       - alt poligon (capacul cilindrului)
       - un cilindru de diametru 0.9 din diametrul primului -> rol de legatura "tier"
       - alt poligon (capac pt tier)



